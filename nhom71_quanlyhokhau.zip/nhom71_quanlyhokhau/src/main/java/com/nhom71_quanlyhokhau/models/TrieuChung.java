package com.nhom71_quanlyhokhau.models;

public class TrieuChung {
    private int id;
    private int idToKhai;
    private String bieuHien;

    
    public TrieuChung() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getIdToKhai() {
        return idToKhai;
    }
    public void setIdToKhai(int idToKhai) {
        this.idToKhai = idToKhai;
    }
    public String getBieuHien() {
        return bieuHien;
    }
    public void setBieuHien(String bieuHien) {
        this.bieuHien = bieuHien;
    }

    
}
