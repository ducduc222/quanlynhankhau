package com.nhom71_quanlyhokhau;

public class Session {
    private static int idAdmin;

    public static int getIdAdmin() {
        return idAdmin;
    }

    public static void setIdAdmin(int idAdmin) {
        Session.idAdmin = idAdmin;
    }
}
